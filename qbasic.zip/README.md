Origins
=======

All of my old QBasic programs, written when I was in grade school. Kept safe here for purely nostalgic reasons.
